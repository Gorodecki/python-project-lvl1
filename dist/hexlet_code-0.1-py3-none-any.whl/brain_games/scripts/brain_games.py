#!/usr/local/bin/ python3
"""Main programm."""


from brain_games.play_game import run_game


def main():
    """Make a user game intreface."""
    run_game()


if __name__ == '__main__':
    main()
