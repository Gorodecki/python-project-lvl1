"""Question collection interface for brain-games."""
from random import randint, choice
from operator import add, sub, mul


INFORMATION = 'What is the result of the expression?'


def generate_question_and_answer():
    """Generate question and answer for game.

    Returns:
        question (str): Question for every game.
        correct_answer (str): Answer for every game 
    """
    number_1 = randint(1, 100)
    number_2 = randint(1, 100)
    operator = choice('-+*')

    if operator == '+':
        result = add(number_1, number_2)
    elif operator == '-':
        result = sub(number_1, number_2)
    elif operator == '*':
        result = mul(number_1, number_2)

    question = '{} {} {}'.format(number_1, operator, number_2)
    correct_answer = str(result)

    return question, correct_answer
